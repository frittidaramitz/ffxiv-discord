# discord-ffxiv-news
FFXIV Lodestone to Discord Webhook Implementation
